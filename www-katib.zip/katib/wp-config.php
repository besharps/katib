<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'katib_db');

/** MySQL database username */
define('DB_USER', 'katib_db_adm');

/** MySQL database password */
define('DB_PASSWORD', 'katibdbadm');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'gF@zOq__aww>41pWDC?o(x<cu1BYlcsOBz^bx}7}TXdO2^HeKT]wjwQ[l.MtB,wp');
define('SECURE_AUTH_KEY',  'wsA~Q7L<cx(R1EFP9zR9)$zf@eSr;HmXCSdV=R|j3$?=bZtN{Iz=H]uDhZgcAcoy');
define('LOGGED_IN_KEY',    'mxWgIANFGg#s`Dkf$$~U|7/9#Xv:=O8_jf}~D5 ypw6]_8`z>^9Fq ,Z0G%]&d7n');
define('NONCE_KEY',        'cn:;na,dWn<}U|Grngg-5-Qyvr:SY!zgL7 *uryM,v(D+FyL&4D6&}u<ZTS6x<Oq');
define('AUTH_SALT',        'UuIi?lW_y0WB|Hg<b#1X&:1N*XQZ6jSuv[epu;`zW<7}=[3D+q4cy2Z3!hKYP|jv');
define('SECURE_AUTH_SALT', 'PDN$<;Y}dHVc{81SFtMzT,-@[6j(e`6wo~$c5#qKUAhowa(kV|CQ8GA<ozSb,PB>');
define('LOGGED_IN_SALT',   '^xW)Qwdr_TMCQR-(,[EB.-fC4=:I+]`aRB17zP[=SlvW<EDa#@HQhVNon##ImsKM');
define('NONCE_SALT',       'ScY*TRo)T&zWRVVdcJ58u*@ew_%{M]sF9NCY>>Lv`-z|?PE|!C_s?QwzBB{4KA`[');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'kt_db_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
