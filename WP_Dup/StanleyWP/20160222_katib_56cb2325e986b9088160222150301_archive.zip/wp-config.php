<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'katib-db');

/** MySQL database username */
define('DB_USER', 'katib-db-adm');

/** MySQL database password */
define('DB_PASSWORD', 'katibdbadm');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'o%o}+NqFeVJzn;$x}46Jx xg#%|0lpVlBJ_=-AG1~XIH=B|dr=Mlu:SYuKd]!E+t');
define('SECURE_AUTH_KEY',  'tsK1v__yKi#n$qLT Y}$n(2=5~G1wj-$^p0aHII0;iH3HO<|)pYI$LL^ MlW]_}/');
define('LOGGED_IN_KEY',    'WFARSFL[<5ylSi/roCChQ[h<W;I*T?>#(Ez8[T-)yoIhrfz8&x|B AM6sl4nwBHb');
define('NONCE_KEY',        'u[JTf}SQMB=bes./92IRGgxHq!3[?9KI1{-|--]?02#+le8tRU-k/m6,B;^M>1W*');
define('AUTH_SALT',        'I&ss%_T>N|~qE(Q-Bq$cbfGi7y4(&LZ@`[$[?I=LX$h=zs+]7a]-%aZ0!{W]c+:$');
define('SECURE_AUTH_SALT', 'HcB|6dl#3XB.lX<8SW|x;}->b@~c[PIdqc6# R&GN.aQbinZ{#9#v<UWLocp!{sE');
define('LOGGED_IN_SALT',   'm(Y|l:E)7|a{p.+te5` _#_.X9mu$grzY,jUQj2 5Ud-[68dZZ -_+E8ARIV/<EM');
define('NONCE_SALT',       '$g+TvMO80vx|xnwYa5U.KLG/kE`,OMb&uW)}<k?Z!%(}ufnyy6l|3`ajgs8eidrz');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'ktb_db_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
